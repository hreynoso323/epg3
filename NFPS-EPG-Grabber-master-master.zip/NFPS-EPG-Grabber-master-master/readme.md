psycon's NFPS Grabber for Kodi Stalker Plugins

INSTRUCTIONS

1. Run Go.bat
2. In  Kodi, Point pvr.stalker/IPTV Simple client to the NFPS.xml file created by this script. 

If  new channels have been added to the guide you have to also:

1. Then purge your EPG database in Kodi>Settings>TV>EPG and purg the PVR database in Kodi>Settings>TV>General
2. Reenable pvr.stalker / IPTV Simple Client





Thanks to Dualtest and Dara, and anyone else who contributed to the channel renaming lists


Copyright 2015 psycon . unauthorized use prohibited...  just kidding.  Just dont forget to mention us.


